# Grain Rot UE4SS

Grain Rot UE4SS community overlay for unreal-shimloader. Mods should depend on this package rather than on `Thunderstore-unreal_shimloader` directly.

## What it does

Grain Rot is Unreal Engine 5.7. Stock UE4SS detects the engine version but cannot resolve three symbols on this build, so it gives up with `Fatal Error: PS scan timed out` and never initialises. This overlay supplies the AOB signature overrides that fix it.

No UE4SS build is bundled. The UE4SS that `Thunderstore-unreal_shimloader` ships works once these signatures are present.

It also disables shimloader's `CheatManagerEnablerMod`, `ConsoleEnablerMod` and `ConsoleCommandsMod`, which otherwise expose Grain Rot's own `Debug*` commands through the console. `BPModLoaderMod` and `BPML_GenericFunctions` stay enabled, so Blueprint mods in `LogicMods`.

## Credits

Signatures from [UE4SS issue #1228](https://github.com/UE4SS-RE/RE-UE4SS/issues/1228) by aslavd, PDB-derived on the same UE 5.7.4 build.
