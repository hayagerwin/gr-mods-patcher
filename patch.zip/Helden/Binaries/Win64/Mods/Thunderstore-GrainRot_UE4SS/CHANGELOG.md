# Changelog

## 1.0.0

Initial release.

- Adds AOB signature overrides for `FName::FName(wchar_t*)`, `StaticConstructObject_Internal`, `GNatives` and `FUObjectHashTables::Get`, without which UE4SS fails its pattern scan on Grain Rot and never initialises.
- Disables shimloader's `CheatManagerEnablerMod`, `ConsoleEnablerMod` and `ConsoleCommandsMod` so the game's `Debug*` commands are not exposed through the console. Blueprint mod loading is unaffected.
