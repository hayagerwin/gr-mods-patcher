# GrainRotTogether

Raise Grain Rot lobby size past the vanilla **4** players. Default is **12**. Only the host needs this installed.

## Install

1. Open [r2modman](https://thunderstore.io/c/grain-rot/p/ebkr/r2modman/) or the Thunderstore Mod Manager.
2. Select **Grain Rot**.
3. Install **GrainRotTogether**. The manager pulls in [GrainRot UE4SS](https://thunderstore.io/c/grain-rot/p/Thunderstore/GrainRot_UE4SS/) for you.
4. Start the game modded and host a lobby.

Joiners do not need the mod. Invite them through Steam as usual.

## Config

Edit `config.ini` in the mod folder, then restart the game.

In r2modman: **Settings → Browse profile folder**, then open `shimloader/mod/Konlet-GrainRotTogether/config.ini`.

```ini
MaxPlayers = 12
Verbose = 0
```

| Key | Default | Range | What it does |
| --- | --- | --- | --- |
| `MaxPlayers` | 12 | 2–16 | Lobby size when you host |
| `Verbose` | 0 | 0 or 1 | Extra field dumps in `UE4SS.log` |

## Who needs it

| Player | Need the mod? |
| --- | --- |
| Host | Yes |
| Friends joining you | No |

## Notes

- This does not retune enemies, the elevator, or loot for larger groups.
- Extra players may share spawn points or spark colors. The game was built around four people.
- Peer-to-peer plus physics at 12 can hitch or desync. Drop `MaxPlayers` if the lobby feels unstable.
- Look for `[GrainRotTogether]` lines in `UE4SS.log` to confirm the override applied.

## Changelog

See [CHANGELOG.md](CHANGELOG.md).
