# Changelog

## 1.0.1

- Point the package website at the Konlet GitHub repo.
- Ship the current Thunderstore icon.

## 1.0.0

- Raise Grain Rot lobby size past the vanilla 4-player cap.
- Default `MaxPlayers = 12`, configurable from 2 to 16 in `config.ini`.
- Host-only. Friends can join without installing the mod.
