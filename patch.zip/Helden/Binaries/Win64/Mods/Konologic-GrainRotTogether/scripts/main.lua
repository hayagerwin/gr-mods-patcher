--[[
    GrainRotTogether
    Host-only UE4SS Lua mod. Raises Grain Rot lobby size past the vanilla 4.
]]

local MOD_TAG = "[GrainRotTogether]"
local MOD_VERSION = "1.0.1"
local DEFAULT_MAX_PLAYERS = 12
local MIN_MAX_PLAYERS = 2
local MAX_MAX_PLAYERS = 16

local VANILLA_CAP = 4
local INIT_GUARD = "__GRAINROT_TOGETHER_INITIALIZED"
local HOOK_RETRY_DELAY_MS = 1000
local MAX_HOOK_ATTEMPTS = 8
local PATCH_RETRY_DELAY_MS = 1500
local DISCOVERY_DELAY_MS = 2500

local FIELD_NAMES = {
    "MaxPlayers",
    "MaxPlayerCount",
    "MaxNumPlayers",
    "MaxSessionPlayerCount",
    "NumPublicConnections",
    "PlayerLimit",
    "LobbySize",
    "LobbyPlayerLimit",
    "MaxLobbyPlayers",
}

local KNOWN_CLASSES = {
    {
        short_name = "GameSession",
        class_name = "/Script/Engine.GameSession",
        cdo_name = "/Script/Engine.Default__GameSession",
        fields = { "MaxPlayers" },
    },
    {
        short_name = "GameModeBase",
        class_name = "/Script/Engine.GameModeBase",
        cdo_name = "/Script/Engine.Default__GameModeBase",
        fields = { "MaxPlayers", "MaxPlayerCount" },
    },
}

local DISCOVERY_CLASS_NAMES = {
    "GameSession",
    "GameModeBase",
    "GameMode",
    "GameStateBase",
    "GameState",
    "OnlineSession",
    "CreateSessionCallbackProxy",
}

local HOST_HOOK_PATHS = {
    "/Script/Engine.GameSession:ApproveLogin",
    "/Script/Engine.GameModeBase:PreLogin",
    "/Script/Engine.GameModeBase:InitGame",
    "/Script/Engine.GameSession:Init",
}

if rawget(_G, INIT_GUARD) then
    print(string.format("%s Duplicate entrypoint skipped\n", MOD_TAG))
    return
end
_G[INIT_GUARD] = true

local TARGET_MAX_PLAYERS = DEFAULT_MAX_PLAYERS
local VERBOSE = false
local hook_attempts = 0
local hooked_paths = {}
local notify_registered = {}
local logged_patches = {}

local function log(message, ...)
    print(string.format("%s %s\n", MOD_TAG, string.format(message, ...)))
end

local function log_verbose(message, ...)
    if VERBOSE then
        log(message, ...)
    end
end

local function trim(s)
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function resolve_mod_dir()
    local src = debug.getinfo(1, "S").source
    local script_dir = src:match("^@?(.+)[/\\][^/\\]+$")
    if not script_dir then
        return nil
    end
    local parent = script_dir:match("^(.+)[/\\][^/\\]+$")
    return parent or script_dir
end

local function parse_ini(path)
    local file = io.open(path, "r")
    if not file then
        return nil
    end
    local values = {}
    for line in file:lines() do
        line = trim(line)
        if line ~= "" and not line:match("^;") and not line:match("^#") then
            local key, value = line:match("^([^=]+)=(.*)$")
            if key and value then
                values[trim(key)] = trim(value)
            end
        end
    end
    file:close()
    return values
end

local function clamp_max_players(value)
    local num = tonumber(value)
    if not num then
        return DEFAULT_MAX_PLAYERS
    end
    num = math.floor(num)
    if num < MIN_MAX_PLAYERS then
        return MIN_MAX_PLAYERS
    end
    if num > MAX_MAX_PLAYERS then
        return MAX_MAX_PLAYERS
    end
    return num
end

local function load_config()
    local mod_dir = resolve_mod_dir()
    local path = mod_dir and (mod_dir .. "/config.ini") or nil
    if path then
        path = path:gsub("\\", "/")
    end
    local win_path = mod_dir and (mod_dir .. "\\config.ini") or nil

    local values = nil
    if path then
        values = parse_ini(path)
    end
    if not values and win_path then
        values = parse_ini(win_path)
    end
    if not values then
        log("config.ini not found, using MaxPlayers=%d", DEFAULT_MAX_PLAYERS)
        return DEFAULT_MAX_PLAYERS, false
    end

    local verbose = values.Verbose == "1" or string.lower(values.Verbose or "") == "true"
    return clamp_max_players(values.MaxPlayers), verbose
end

TARGET_MAX_PLAYERS, VERBOSE = load_config()

local function is_valid(obj)
    if not obj then
        return false
    end
    local ok, valid = pcall(function()
        return obj.IsValid and obj:IsValid()
    end)
    return ok and valid == true
end

local function unwrap_param(param)
    if param == nil then
        return nil
    end
    local ok_type, ue_type = pcall(function()
        return param:type()
    end)
    if ok_type and (ue_type == "RemoteUnrealParam" or ue_type == "LocalUnrealParam") then
        local ok_get, value = pcall(function()
            return param:get()
        end)
        if ok_get then
            return value
        end
    end
    return param
end

local function object_label(obj)
    local name = "?"
    pcall(function()
        name = obj:GetFullName() or obj:GetName() or "?"
    end)
    return name
end

local function patch_key(obj, field_name)
    return object_label(obj) .. "." .. field_name
end

local function looks_like_player_cap(value)
    return type(value) == "number" and value >= 1 and value <= MAX_MAX_PLAYERS
end

local function set_numeric_field(obj, field_name, scope)
    if not is_valid(obj) then
        return false
    end
    local ok_read, current = pcall(function()
        return obj[field_name]
    end)
    if not ok_read or not looks_like_player_cap(current) then
        return false
    end
    if current == TARGET_MAX_PLAYERS then
        return true
    end
    -- Skip values that do not look like the vanilla lobby cap unless this is a known MaxPlayers field.
    if current ~= VANILLA_CAP and field_name ~= "MaxPlayers" and field_name ~= "NumPublicConnections" then
        log_verbose("Skip %s.%s=%s (not vanilla cap)", scope, field_name, tostring(current))
        return false
    end
    local ok_write, err = pcall(function()
        obj[field_name] = TARGET_MAX_PLAYERS
    end)
    if not ok_write then
        log("Failed to write %s.%s: %s", scope, field_name, tostring(err))
        return false
    end
    local key = patch_key(obj, field_name)
    if not logged_patches[key] then
        logged_patches[key] = true
        log("%s.%s: %s -> %d", scope, field_name, tostring(current), TARGET_MAX_PLAYERS)
    else
        log_verbose("%s.%s: %s -> %d", scope, field_name, tostring(current), TARGET_MAX_PLAYERS)
    end
    return true
end

local function patch_object_fields(obj, fields, scope)
    if not is_valid(obj) then
        return false
    end
    local patched = false
    for _, field_name in ipairs(fields) do
        if set_numeric_field(obj, field_name, scope) then
            patched = true
        end
    end
    return patched
end

local function patch_object_all_cap_fields(obj, scope)
    return patch_object_fields(obj, FIELD_NAMES, scope)
end

local function patch_cdo(config)
    local ok, obj = pcall(function()
        return StaticFindObject(config.cdo_name)
    end)
    if not ok or not is_valid(obj) then
        log_verbose("CDO %s not found at %s", config.short_name, config.cdo_name)
        return
    end
    patch_object_fields(obj, config.fields, "CDO " .. config.short_name)
end

local function patch_instances(short_name, fields)
    local ok, objects = pcall(function()
        return FindAllOf(short_name)
    end)
    if not ok or not objects then
        return
    end
    for index, obj in ipairs(objects) do
        patch_object_fields(obj, fields, string.format("%s[%d]", short_name, index))
    end
end

local function register_new_object_notify(class_name, short_name, fields)
    if notify_registered[class_name] then
        return
    end
    local ok, err = pcall(function()
        NotifyOnNewObject(class_name, function(new_obj)
            patch_object_fields(new_obj, fields, "New " .. short_name)
        end)
    end)
    if ok then
        notify_registered[class_name] = true
        log("NotifyOnNewObject armed for %s", short_name)
    else
        log_verbose("NotifyOnNewObject failed for %s: %s", short_name, tostring(err))
    end
end

local function apply_known_patches()
    for _, config in ipairs(KNOWN_CLASSES) do
        patch_cdo(config)
        patch_instances(config.short_name, config.fields)
        register_new_object_notify(config.class_name, config.short_name, config.fields)
    end
end

local function dump_cap_fields(obj, scope)
    if not VERBOSE or not is_valid(obj) then
        return
    end
    for _, field_name in ipairs(FIELD_NAMES) do
        local ok, value = pcall(function()
            return obj[field_name]
        end)
        if ok and type(value) == "number" then
            log_verbose("dump %s %s=%s (%s)", scope, field_name, tostring(value), object_label(obj))
        end
    end
end

local function discover_and_patch()
    for _, short_name in ipairs(DISCOVERY_CLASS_NAMES) do
        local ok, objects = pcall(function()
            return FindAllOf(short_name)
        end)
        if ok and objects then
            for index, obj in ipairs(objects) do
                local scope = string.format("Discover %s[%d]", short_name, index)
                dump_cap_fields(obj, scope)
                patch_object_all_cap_fields(obj, scope)
            end
        end
    end
end

local function patch_hook_context(self_unwrapped, args, hook_name)
    local self_obj = unwrap_param(self_unwrapped)
    if is_valid(self_obj) then
        patch_object_all_cap_fields(self_obj, hook_name .. " self")
        dump_cap_fields(self_obj, hook_name .. " self")
    end
    apply_known_patches()
    if not args then
        return
    end
    for i, raw in ipairs(args) do
        local arg = unwrap_param(raw)
        if is_valid(arg) then
            patch_object_all_cap_fields(arg, string.format("%s arg[%d]", hook_name, i))
        end
    end
end

local function try_register_hooks()
    hook_attempts = hook_attempts + 1
    local newly_hooked = false
    for _, path in ipairs(HOST_HOOK_PATHS) do
        if not hooked_paths[path] then
            local ok, pre_id = pcall(function()
                return RegisterHook(path, function(self, ...)
                    patch_hook_context(self, { ... }, path)
                end)
            end)
            if ok and pre_id ~= nil then
                hooked_paths[path] = true
                newly_hooked = true
                log("Hooked %s", path)
            else
                log_verbose("Hook unavailable: %s", path)
            end
        end
    end
    return newly_hooked
end

local function retry_hooks()
    try_register_hooks()
    if hook_attempts < MAX_HOOK_ATTEMPTS then
        ExecuteWithDelay(HOOK_RETRY_DELAY_MS, function()
            ExecuteInGameThread(retry_hooks)
        end)
    end
end

local function bootstrap()
    log("v%s loading. Target MaxPlayers=%d (range %d-%d)", MOD_VERSION, TARGET_MAX_PLAYERS, MIN_MAX_PLAYERS, MAX_MAX_PLAYERS)
    apply_known_patches()
    try_register_hooks()
    discover_and_patch()
end

ExecuteInGameThread(bootstrap)

ExecuteWithDelay(PATCH_RETRY_DELAY_MS, function()
    ExecuteInGameThread(function()
        apply_known_patches()
        discover_and_patch()
        try_register_hooks()
    end)
end)

ExecuteWithDelay(DISCOVERY_DELAY_MS, function()
    ExecuteInGameThread(function()
        discover_and_patch()
        retry_hooks()
    end)
end)
